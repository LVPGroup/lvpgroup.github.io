# PiCore
A Rely-guarantee Reasoning Framework for Concurrent Event-based Systems.
Developed by **Yongwang Zhao**, in Isabelle/HOL 2019.

## Usage
Download Isabelle/HOL 2019, and open PiCore sources. 

## File structure
### picore
The event specification language, its rely-guarantee proof system and invariant verification approach. 

### adapter_SIMP
The picore adapter for the IMP language, which is a simple imperative language with a rely-guarantee proof system provided by the Hoare_Parallel library of Isabelle/HOL.

### CSimpl
The CSimpl language in Isabelle/HOL 2019. CSimpl is a generic and realistic imperative language by extending Simpl and providing a rely-guarantee proof system in Isabelle/HOL. Simpl is able to represent a large subset of C99 code and has been applied to the formal verification of seL4 OS kernel at C code level.

### adapter_CSimpl
The picore adapter for the CSimpl language. 

### cases/BPEL
PiCore formalization of the BPEL standard by an automated translator. The correctness of this translation has been proved by a bisimulation relation.

### cases/mempool_v1.00
The formal specification and rely-guarantee proof of Zephyr concurrent memory management in PiCore. 


