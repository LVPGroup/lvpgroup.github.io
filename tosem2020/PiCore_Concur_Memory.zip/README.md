# PiCore
A Rely-guarantee Reasoning Framework for Concurrent Event-based Systems.
Developed by **Yongwang Zhao**, in Isabelle/HOL 2018.

## Usage
Download Isabelle/HOL 2018, and open PiCore sources. 

## File structure
### picore
The event specification language, its rely-guarantee proof system and invariant verification approach. 

### IFS
The compositional verification of information-flow security. 

### adapter_SIMP
The picore adapter for the IMP language, which is a simple imperative language with a rely-guarantee proof system provided by the Hoare_Parallel library of Isabelle/HOL.

### cases/mempool_v1.20_SIMP
The formal specification and rely-guarantee proof of Zephyr concurrent memory management in PiCore. 


